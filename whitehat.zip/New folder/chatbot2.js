 const userMessage = [];

const botReply = [
    ["Hello! can i assist u?"],
    ["How many number of Faculty do you want to assign"],
    ["faculty are being assinged"], 
    ["Download the list ?"],
    ["list is downloading..."],
];

const alternative = [
    ["can you be more specific."]
    
];

const synth = window.speechSynthesis;

function voiceControl(string) {
    let u = new SpeechSynthesisUtterance(string);
    u.text = string;
    u.lang = "en-US";
    u.volume = 10;
    u.rate = 2;
    u.pitch = 2;
    synth.speak(u);
}

function startVoiceRecognition() {
    const recognition = new window.webkitSpeechRecognition();
    recognition.continuous = true;  // Set to false to stop after each recognition
    recognition.lang = 'en-US';

    recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        document.getElementById('input').value = transcript;
        sendMessage();

        // Stop recognition after processing speech
        recognition.stop();
    };

    recognition.onend = () => {
        console.log('Voice recognition ended.');
    };

    recognition.start();
}

function sendMessage() {
    const inputField = document.getElementById("input");
    let input = inputField.value.trim();
    userMessage.push([input]);
    input != "" && output(input);
    inputField.value = "";
}

function output(input) {
    let product;

    let text = input.toLowerCase().replace(/[^\w\s\d]/gi, " ");

    text = text
        .replace(/[\W_]/g, " ")
        .replace(/ a /g, " ")
        .replace(/i feel /g, "")
        .replace(/whats/g, "what is")
        .replace(/please /g, "")
        .replace(/ please/g, "")
        .trim();

    let comparedText = compare(userMessage, botReply, text);

    product = comparedText
        ? comparedText
        : alternative[Math.floor(Math.random() * alternative.length)];
    document.getElementById('input').value = '';

    addChat(input, product);
    speak(product)
}

function compare(triggerArray, replyArray, string) {
    let item;
    for (let x = 0; x < triggerArray.length; x++) {
        for (let y = 0; y < replyArray.length; y++) {
            if (triggerArray[x][y] == string) {
                items = replyArray[x];
                item = items[Math.floor(Math.random() * items.length)];
            }
        }
    }

    if (item) return item;
    else return containMessageCheck(string);
}

function containMessageCheck(string) {
    let expectedReply = [
        // ... (your predefined expected replies)
    ];
    let expectedMessage = [
        // ... (your predefined expected messages)
    ];
    let item;
    for (let x = 0; x < expectedMessage.length; x++) {
        if (expectedMessage[x].includes(string)) {
            items = expectedReply[x];
            item = items[Math.floor(Math.random() * items.length)];
        }
    }
    return item;
}

function addChat(input, product) {
    const mainDiv = document.getElementById("message-section");
    let userDiv = document.createElement("div");
    userDiv.id = "user";
    userDiv.classList.add("message");
    userDiv.innerHTML = `<span id="user-response">${input}</span>`;
    mainDiv.appendChild(userDiv);

    let botDiv = document.createElement("div");
    botDiv.id = "bot";
    botDiv.classList.add("message");
    botDiv.innerHTML = `<span id="bot-response">${product}</span>`;
    mainDiv.appendChild(botDiv);
    var scroll = document.getElementById("message-section");
    scroll.scrollTop = scroll.scrollHeight;
    voiceControl(product);
}
